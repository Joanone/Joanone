# Structured-Sparse-Bayesian-Learning

All the methods incorporated into this packeage are based on modalities of Structured-Sparse-Bayesian-Learning (Hierarchical Elastic Net or Hierarchical Elitist LASSO), presented in:

Paz-Linares, D., Vega-Hernandez, M., Rojas-Lopez, P.A., Valdes-Hernandez, P.A., Martinez-Montes, E. and Valdes-Sosa, P.A., 2017. Spatio temporal EEG source imaging with the hierarchical bayesian elastic net and elitist lasso models. Frontiers in neuroscience, 11, p.635.
